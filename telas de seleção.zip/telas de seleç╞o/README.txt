As telas de seleção são literalmente a mesma coisa, porém a pós-seleção so adiciona a porcentagem.
Então a tela de pós-seleção vai ser feita quando for implementar totalmente as telas com suas funcionalidades.
